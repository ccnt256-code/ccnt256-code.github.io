@echo off
chcp 65001 >nul
echo ============================================
echo   네이버 블로그 자동 포스팅 - 설치
echo ============================================
echo.

:: Python 확인
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python이 설치되어 있지 않습니다!
    echo.
    echo 아래 링크에서 Python을 설치해주세요:
    echo https://www.python.org/downloads/
    echo.
    echo ⚠️ 설치 시 "Add Python to PATH" 체크 필수!
    pause
    exit /b 1
)

echo ✅ Python 확인 완료
echo.
echo 📦 패키지 설치 중...
pip install -r requirements.txt
echo.

:: .env 파일 생성
if not exist .env (
    echo 📝 설정 파일 생성 중...
    copy .env.example .env >nul
    echo.
    echo ⚠️ .env 파일을 메모장으로 열어서 네이버 ID/PW를 입력해주세요!
    notepad .env
)

echo.
echo ============================================
echo   ✅ 설치 완료!
echo   실행: run.bat 더블클릭
echo ============================================
pause
