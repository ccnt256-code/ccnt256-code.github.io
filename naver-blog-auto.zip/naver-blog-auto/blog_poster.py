"""
네이버 블로그 자동 포스팅 모듈
SmartEditor ONE에서 글 작성 → 발행까지 자동화
"""

import time
import random
import logging
import os
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

from naver_login import human_type

logger = logging.getLogger(__name__)

# SmartEditor ONE URL
EDITOR_URL = "https://blog.naver.com/{blog_id}/postwrite"


def open_editor(driver, blog_id, timeout=15):
    """블로그 글쓰기 에디터를 엽니다."""
    url = EDITOR_URL.format(blog_id=blog_id)
    logger.info(f"에디터 열기: {url}")
    driver.get(url)
    time.sleep(3)
    
    wait = WebDriverWait(driver, timeout)
    
    # SmartEditor iframe 로드 대기
    try:
        # SE ONE 에디터는 iframe 내부에 있을 수 있음
        wait.until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, ".se-component-content, .se_editArea, #mainFrame")
            )
        )
        logger.info("에디터 로드 완료")
        return True
    except Exception as e:
        logger.error(f"에디터 로드 실패: {e}")
        return False


def switch_to_editor_frame(driver):
    """SmartEditor iframe으로 전환합니다."""
    try:
        # mainFrame이 있으면 전환
        iframe = driver.find_element(By.ID, "mainFrame")
        driver.switch_to.frame(iframe)
        logger.info("mainFrame으로 전환")
        return True
    except Exception:
        # iframe 없으면 이미 메인 프레임
        return False


def input_title(driver, title, timeout=10):
    """
    블로그 제목을 입력합니다.
    키스트로크 방식으로 한 글자씩 입력.
    """
    wait = WebDriverWait(driver, timeout)
    
    try:
        # SE ONE 제목 영역
        title_area = wait.until(
            EC.element_to_be_clickable(
                (By.CSS_SELECTOR, ".se-ff-nanumgothic.se-fs32, .se-title-text, span.se-fs-")
            )
        )
        title_area.click()
        time.sleep(0.5)
        
        # 제목 입력 (키스트로크)
        logger.info(f"제목 입력: {title[:30]}...")
        human_type(title_area, title, min_delay=0.03, max_delay=0.08)
        time.sleep(0.5)
        
        logger.info("✅ 제목 입력 완료")
        return True
        
    except Exception as e:
        logger.error(f"제목 입력 실패: {e}")
        # 대체 방법: ActionChains
        try:
            actions = ActionChains(driver)
            # 제목 영역 찾기 (다양한 셀렉터 시도)
            selectors = [
                ".se-documentTitle .se-text-paragraph",
                "[contenteditable='true']",
                ".se-section-title"
            ]
            for sel in selectors:
                try:
                    el = driver.find_element(By.CSS_SELECTOR, sel)
                    el.click()
                    time.sleep(0.3)
                    human_type(el, title, min_delay=0.03, max_delay=0.08)
                    logger.info(f"✅ 제목 입력 완료 (대체 셀렉터: {sel})")
                    return True
                except Exception:
                    continue
        except Exception:
            pass
        return False


def input_content(driver, content, timeout=10):
    """
    블로그 본문을 입력합니다.
    줄바꿈은 Enter로, 단락 구분은 Enter 2번으로 처리.
    """
    wait = WebDriverWait(driver, timeout)
    
    try:
        # 본문 영역 찾기
        body_selectors = [
            ".se-component-content .se-text-paragraph",
            ".se-main-container .se-text-paragraph",
            ".se-section-text .se-text-paragraph",
        ]
        
        body_area = None
        for sel in body_selectors:
            try:
                body_area = wait.until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, sel))
                )
                break
            except Exception:
                continue
        
        if not body_area:
            # 제목 입력 후 Tab/Enter로 본문 이동
            actions = ActionChains(driver)
            actions.send_keys(Keys.ENTER)
            actions.perform()
            time.sleep(0.5)
            
            # 현재 활성 요소 사용
            body_area = driver.switch_to.active_element
        
        body_area.click()
        time.sleep(0.5)
        
        # 본문 입력 — 줄 단위로 처리
        lines = content.split('\n')
        logger.info(f"본문 입력 시작 ({len(lines)}줄)...")
        
        for i, line in enumerate(lines):
            if line.strip():
                # 텍스트가 있는 줄은 키스트로크 입력
                human_type(
                    driver.switch_to.active_element,
                    line,
                    min_delay=0.02,
                    max_delay=0.06
                )
            
            # 줄바꿈 (마지막 줄 제외)
            if i < len(lines) - 1:
                driver.switch_to.active_element.send_keys(Keys.ENTER)
                time.sleep(random.uniform(0.1, 0.3))
            
            # 진행률 로그 (50줄마다)
            if (i + 1) % 50 == 0:
                logger.info(f"  ... {i+1}/{len(lines)}줄 입력 완료")
        
        logger.info("✅ 본문 입력 완료")
        return True
        
    except Exception as e:
        logger.error(f"본문 입력 실패: {e}")
        return False


def input_tags(driver, tags, timeout=10):
    """
    블로그 태그를 입력합니다.
    태그는 쉼표나 엔터로 구분하여 하나씩 입력.
    
    Args:
        tags: 태그 리스트 (예: ["울산타이어", "미쉐린", "타이어교체"])
    """
    try:
        # 태그 입력 영역 찾기
        tag_selectors = [
            ".tag_input input",
            "#post-tag-input",
            "input[placeholder*='태그']",
            ".se-tag-input input",
        ]
        
        tag_input = None
        for sel in tag_selectors:
            try:
                tag_input = driver.find_element(By.CSS_SELECTOR, sel)
                break
            except Exception:
                continue
        
        if not tag_input:
            logger.warning("태그 입력 필드를 찾을 수 없음")
            return False
        
        tag_input.click()
        time.sleep(0.5)
        
        for tag in tags:
            human_type(tag_input, tag, min_delay=0.03, max_delay=0.08)
            time.sleep(0.3)
            tag_input.send_keys(Keys.ENTER)
            time.sleep(random.uniform(0.3, 0.6))
            logger.info(f"  태그 추가: {tag}")
        
        logger.info(f"✅ 태그 {len(tags)}개 입력 완료")
        return True
        
    except Exception as e:
        logger.error(f"태그 입력 실패: {e}")
        return False


def set_category(driver, category_name, timeout=10):
    """블로그 카테고리를 설정합니다."""
    try:
        # 카테고리 버튼 클릭
        cat_btn = driver.find_element(
            By.CSS_SELECTOR, ".se-category-btn, .category_btn, [class*='category']"
        )
        cat_btn.click()
        time.sleep(1)
        
        # 카테고리 목록에서 선택
        categories = driver.find_elements(
            By.CSS_SELECTOR, ".se-category-item, .category_item, li[class*='category']"
        )
        
        for cat in categories:
            if category_name in cat.text:
                cat.click()
                logger.info(f"✅ 카테고리 설정: {category_name}")
                time.sleep(0.5)
                return True
        
        logger.warning(f"카테고리를 찾을 수 없음: {category_name}")
        return False
        
    except Exception as e:
        logger.error(f"카테고리 설정 실패: {e}")
        return False


def publish_post(driver, timeout=10):
    """
    글을 발행합니다.
    발행 버튼 클릭 → 공개 설정 확인 → 최종 발행
    """
    try:
        # 발행 버튼 찾기
        publish_selectors = [
            "button.publish_btn__Y9Nl7",
            "button[class*='publish']",
            ".se-publish-btn",
            "button.btn_publish",
            "//button[contains(text(), '발행')]",
        ]
        
        publish_btn = None
        for sel in publish_selectors:
            try:
                if sel.startswith("//"):
                    publish_btn = driver.find_element(By.XPATH, sel)
                else:
                    publish_btn = driver.find_element(By.CSS_SELECTOR, sel)
                break
            except Exception:
                continue
        
        if not publish_btn:
            logger.error("발행 버튼을 찾을 수 없음")
            return False
        
        publish_btn.click()
        logger.info("발행 버튼 클릭")
        time.sleep(2)
        
        # 발행 확인 모달이 뜨면 최종 확인
        try:
            confirm_selectors = [
                "button.confirm_btn",
                "button[class*='confirm']",
                ".layer_post button.btn_ok",
                "//button[contains(text(), '발행')]",
            ]
            
            for sel in confirm_selectors:
                try:
                    if sel.startswith("//"):
                        confirm_btn = driver.find_element(By.XPATH, sel)
                    else:
                        confirm_btn = driver.find_element(By.CSS_SELECTOR, sel)
                    confirm_btn.click()
                    logger.info("발행 확인 클릭")
                    break
                except Exception:
                    continue
                    
        except Exception:
            pass
        
        time.sleep(3)
        logger.info("✅ 글 발행 완료!")
        return True
        
    except Exception as e:
        logger.error(f"발행 실패: {e}")
        return False


def create_post(driver, blog_id, title, content, tags=None, category=None, publish=False):
    """
    블로그 글 작성 전체 워크플로우
    
    Args:
        driver: WebDriver
        blog_id: 블로그 ID
        title: 글 제목
        content: 글 본문
        tags: 태그 리스트 (선택)
        category: 카테고리 이름 (선택)
        publish: True면 바로 발행, False면 임시저장
    
    Returns:
        bool: 성공 여부
    """
    logger.info("=" * 50)
    logger.info(f"글 작성 시작: {title[:40]}...")
    logger.info("=" * 50)
    
    # 1) 에디터 열기
    if not open_editor(driver, blog_id):
        return False
    
    # iframe 전환 (필요 시)
    switch_to_editor_frame(driver)
    time.sleep(1)
    
    # 2) 제목 입력
    if not input_title(driver, title):
        return False
    time.sleep(0.5)
    
    # 3) 본문 입력
    if not input_content(driver, content):
        return False
    time.sleep(0.5)
    
    # 4) 카테고리 설정 (선택)
    if category:
        set_category(driver, category)
        time.sleep(0.5)
    
    # 5) 태그 입력 (선택)
    if tags:
        input_tags(driver, tags)
        time.sleep(0.5)
    
    # 6) 발행 또는 임시저장
    if publish:
        return publish_post(driver)
    else:
        logger.info("📝 임시저장 모드 — 발행하지 않음")
        return True
