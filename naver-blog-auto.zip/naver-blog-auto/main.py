#!/usr/bin/env python3
"""
네이버 블로그 자동 포스팅 프로그램
===================================
클로드 코드 + 브라우저 자동화 방식

사용법:
  python main.py                          # 대화형 모드
  python main.py --title "제목" --file content.txt   # 파일에서 본문 읽기
  python main.py --title "제목" --content "본문"     # 직접 본문 입력
  python main.py --login-only             # 로그인만 (쿠키 저장)
"""

import argparse
import logging
import os
import sys
import json
from dotenv import load_dotenv

from browser_setup import create_driver, close_driver
from naver_login import login_naver, load_cookies, save_cookies, check_login_status
from blog_poster import create_post

# ─── 로깅 설정 ──────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger(__name__)

# ─── 환경 변수 로드 ──────────────────────────────────
load_dotenv()

NAVER_ID = os.getenv("NAVER_ID", "")
NAVER_PW = os.getenv("NAVER_PW", "")
BLOG_ID = os.getenv("BLOG_ID", "")
CHROME_PATH = os.getenv("CHROME_PATH", "")
CHROME_PROFILE = os.getenv("CHROME_PROFILE_DIR", "")
COOKIE_FILE = os.path.join(os.path.dirname(__file__), "cookies.json")


def do_login(driver):
    """로그인 수행 (쿠키 우선 → 키스트로크 로그인)"""
    
    # 1) 쿠키로 먼저 시도
    if os.path.exists(COOKIE_FILE):
        logger.info("저장된 쿠키로 로그인 시도...")
        if load_cookies(driver, COOKIE_FILE):
            return True
    
    # 2) 키스트로크 로그인
    if not NAVER_ID or not NAVER_PW:
        logger.error("❌ NAVER_ID, NAVER_PW가 .env에 설정되지 않았습니다")
        sys.exit(1)
    
    success = login_naver(driver, NAVER_ID, NAVER_PW)
    
    if success:
        # 쿠키 저장 (다음에 재사용)
        save_cookies(driver, COOKIE_FILE)
    
    return success


def interactive_mode(driver):
    """대화형 모드로 글 작성"""
    print("\n" + "=" * 50)
    print("📝 네이버 블로그 자동 포스팅")
    print("=" * 50)
    
    title = input("\n제목: ").strip()
    if not title:
        print("제목을 입력해주세요!")
        return
    
    print("\n본문을 입력하세요 (입력 끝: 빈 줄에서 Ctrl+D 또는 'END' 입력):")
    lines = []
    while True:
        try:
            line = input()
            if line.strip() == "END":
                break
            lines.append(line)
        except EOFError:
            break
    
    content = "\n".join(lines)
    if not content.strip():
        print("본문을 입력해주세요!")
        return
    
    tags_input = input("\n태그 (쉼표 구분, 빈칸이면 건너뜀): ").strip()
    tags = [t.strip() for t in tags_input.split(",") if t.strip()] if tags_input else None
    
    category = input("카테고리 (빈칸이면 건너뜀): ").strip() or None
    
    publish_yn = input("\n바로 발행할까요? (y/N): ").strip().lower()
    publish = publish_yn in ("y", "yes", "ㅇ")
    
    print(f"\n{'─' * 40}")
    print(f"제목: {title}")
    print(f"본문: {len(content)}자")
    print(f"태그: {tags}")
    print(f"카테고리: {category}")
    print(f"발행: {'즉시 발행' if publish else '임시저장'}")
    print(f"{'─' * 40}")
    
    confirm = input("진행할까요? (y/N): ").strip().lower()
    if confirm not in ("y", "yes", "ㅇ"):
        print("취소됨")
        return
    
    create_post(driver, BLOG_ID, title, content, tags=tags, category=category, publish=publish)


def file_mode(driver, title, filepath, tags=None, category=None, publish=False):
    """파일에서 본문을 읽어서 글 작성"""
    if not os.path.exists(filepath):
        logger.error(f"파일을 찾을 수 없음: {filepath}")
        return
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    logger.info(f"파일에서 본문 로드: {filepath} ({len(content)}자)")
    create_post(driver, BLOG_ID, title, content, tags=tags, category=category, publish=publish)


def main():
    parser = argparse.ArgumentParser(description="네이버 블로그 자동 포스팅")
    parser.add_argument("--title", help="글 제목")
    parser.add_argument("--content", help="글 본문 (직접 입력)")
    parser.add_argument("--file", help="본문 파일 경로")
    parser.add_argument("--tags", help="태그 (쉼표 구분)")
    parser.add_argument("--category", help="카테고리")
    parser.add_argument("--publish", action="store_true", help="즉시 발행 (기본: 임시저장)")
    parser.add_argument("--login-only", action="store_true", help="로그인만 수행 (쿠키 저장)")
    parser.add_argument("--headless", action="store_true", help="헤드리스 모드")
    parser.add_argument("--json", help="JSON 파일에서 글 정보 읽기")
    
    args = parser.parse_args()
    
    # 블로그 ID 확인
    if not BLOG_ID and not args.login_only:
        logger.error("❌ BLOG_ID가 .env에 설정되지 않았습니다")
        sys.exit(1)
    
    # 드라이버 생성
    driver = create_driver(
        headless=args.headless,
        chrome_path=CHROME_PATH or None,
        profile_dir=CHROME_PROFILE or None
    )
    
    try:
        # 로그인
        if not do_login(driver):
            logger.error("❌ 로그인 실패. 프로그램을 종료합니다.")
            return
        
        # 로그인만 모드
        if args.login_only:
            logger.info("✅ 로그인 완료. 쿠키가 저장되었습니다.")
            input("Enter를 누르면 브라우저를 닫습니다...")
            return
        
        # JSON 파일 모드
        if args.json:
            with open(args.json, 'r', encoding='utf-8') as f:
                post_data = json.load(f)
            create_post(
                driver, BLOG_ID,
                title=post_data["title"],
                content=post_data["content"],
                tags=post_data.get("tags"),
                category=post_data.get("category"),
                publish=post_data.get("publish", False)
            )
        
        # 파일 모드
        elif args.file:
            if not args.title:
                logger.error("--file 사용 시 --title이 필요합니다")
                return
            tags = [t.strip() for t in args.tags.split(",")] if args.tags else None
            file_mode(driver, args.title, args.file, tags=tags, category=args.category, publish=args.publish)
        
        # 직접 입력 모드
        elif args.title and args.content:
            tags = [t.strip() for t in args.tags.split(",")] if args.tags else None
            create_post(
                driver, BLOG_ID,
                title=args.title,
                content=args.content,
                tags=tags,
                category=args.category,
                publish=args.publish
            )
        
        # 대화형 모드
        else:
            interactive_mode(driver)
    
    finally:
        close_driver(driver)


if __name__ == "__main__":
    main()
