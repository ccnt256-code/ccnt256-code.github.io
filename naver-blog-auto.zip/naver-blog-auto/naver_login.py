"""
네이버 로그인 모듈 — 키스트로크 방식 입력 처리
네이버 봇 감지를 우회하기 위해 클립보드가 아닌 실제 키보드 입력을 시뮬레이션합니다.
"""

import time
import random
import logging
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

logger = logging.getLogger(__name__)

# ─── 키스트로크 설정 ─────────────────────────────────
MIN_DELAY = 0.05   # 최소 타이핑 딜레이 (초)
MAX_DELAY = 0.15   # 최대 타이핑 딜레이 (초)
TYPO_CHANCE = 0.0  # 오타 확률 (0 = 오타 없음, 실제 사용 시 0으로)


def human_type(element, text, min_delay=MIN_DELAY, max_delay=MAX_DELAY):
    """
    사람처럼 한 글자씩 타이핑합니다.
    - 글자 사이에 랜덤 딜레이
    - 가끔 짧은 멈춤 (단어 경계)
    """
    for i, char in enumerate(text):
        element.send_keys(char)
        
        # 기본 랜덤 딜레이
        delay = random.uniform(min_delay, max_delay)
        
        # 가끔 더 긴 멈춤 (사람처럼)
        if random.random() < 0.1:
            delay += random.uniform(0.1, 0.3)
        
        time.sleep(delay)


def clear_field(driver, element):
    """입력 필드를 깨끗하게 비웁니다."""
    actions = ActionChains(driver)
    actions.click(element)
    actions.key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL)
    actions.send_keys(Keys.DELETE)
    actions.perform()
    time.sleep(0.3)


def login_naver(driver, naver_id, naver_pw, timeout=30):
    """
    네이버 로그인을 키스트로크 방식으로 수행합니다.
    
    Args:
        driver: Selenium WebDriver 인스턴스
        naver_id: 네이버 아이디
        naver_pw: 네이버 비밀번호
        timeout: 최대 대기 시간 (초)
    
    Returns:
        bool: 로그인 성공 여부
    """
    logger.info("네이버 로그인 시작...")
    
    # 1) 네이버 로그인 페이지로 이동
    driver.get("https://nid.naver.com/nidlogin.login")
    time.sleep(random.uniform(1.5, 2.5))
    
    wait = WebDriverWait(driver, timeout)
    
    try:
        # 2) 아이디 입력 필드 찾기
        id_field = wait.until(
            EC.presence_of_element_located((By.ID, "id"))
        )
        logger.info("아이디 필드 발견")
        
        # 필드 클릭 후 잠시 대기 (사람처럼)
        id_field.click()
        time.sleep(random.uniform(0.3, 0.7))
        
        # 기존 내용 삭제
        clear_field(driver, id_field)
        
        # 3) 아이디 키스트로크 입력
        logger.info("아이디 입력 중...")
        human_type(id_field, naver_id)
        time.sleep(random.uniform(0.5, 1.0))
        
        # 4) 비밀번호 필드로 이동
        pw_field = driver.find_element(By.ID, "pw")
        pw_field.click()
        time.sleep(random.uniform(0.3, 0.7))
        
        # 기존 내용 삭제
        clear_field(driver, pw_field)
        
        # 5) 비밀번호 키스트로크 입력
        logger.info("비밀번호 입력 중...")
        human_type(pw_field, naver_pw)
        time.sleep(random.uniform(0.5, 1.0))
        
        # 6) 로그인 버튼 클릭
        login_btn = driver.find_element(By.ID, "log.login")
        time.sleep(random.uniform(0.3, 0.5))
        login_btn.click()
        logger.info("로그인 버튼 클릭")
        
        # 7) 로그인 결과 확인
        time.sleep(3)
        
        # 캡차 또는 2단계 인증 체크
        current_url = driver.current_url
        
        if "nidlogin" in current_url:
            # 아직 로그인 페이지에 있음
            # 캡차가 있는지 확인
            try:
                captcha = driver.find_element(By.ID, "captcha")
                logger.warning("⚠️ 캡차가 감지되었습니다! 수동 입력이 필요합니다.")
                logger.info("캡차를 수동으로 입력해주세요... (60초 대기)")
                
                # 캡차 수동 입력 대기
                for i in range(60):
                    time.sleep(1)
                    if "nidlogin" not in driver.current_url:
                        break
                        
            except Exception:
                pass
            
            # 새 기기 등록 안내가 있는지 확인
            try:
                new_device = driver.find_element(By.CSS_SELECTOR, ".new_device")
                skip_btn = driver.find_element(By.CSS_SELECTOR, ".btn_skip, #new.dontsave")
                skip_btn.click()
                logger.info("새 기기 등록 건너뜀")
                time.sleep(2)
            except Exception:
                pass
        
        # "등록 안함" 또는 "나중에" 버튼 처리
        try:
            later_btn = driver.find_element(By.CSS_SELECTOR, "a.btn_cancel, button.btn_cancel")
            later_btn.click()
            time.sleep(1)
        except Exception:
            pass
        
        # 8) 최종 로그인 확인
        driver.get("https://www.naver.com")
        time.sleep(2)
        
        # 로그인 상태 확인 (네이버 메인에서)
        try:
            driver.find_element(By.CSS_SELECTOR, ".MyView-module__link_login___HpHMW, .link_login, #account")
            logger.error("❌ 로그인 실패: 여전히 비로그인 상태")
            return False
        except Exception:
            logger.info("✅ 네이버 로그인 성공!")
            return True
            
    except Exception as e:
        logger.error(f"❌ 로그인 중 오류 발생: {e}")
        return False


def check_login_status(driver):
    """현재 로그인 상태를 확인합니다."""
    try:
        driver.get("https://www.naver.com")
        time.sleep(2)
        # 로그인 버튼이 있으면 비로그인 상태
        driver.find_element(By.CSS_SELECTOR, ".MyView-module__link_login___HpHMW, .link_login")
        return False
    except Exception:
        return True


def save_cookies(driver, filepath="cookies.json"):
    """로그인 쿠키를 파일로 저장합니다."""
    import json
    cookies = driver.get_cookies()
    with open(filepath, 'w') as f:
        json.dump(cookies, f, indent=2)
    logger.info(f"쿠키 저장 완료: {filepath}")


def load_cookies(driver, filepath="cookies.json"):
    """저장된 쿠키를 로드합니다."""
    import json
    import os
    
    if not os.path.exists(filepath):
        logger.warning(f"쿠키 파일 없음: {filepath}")
        return False
    
    try:
        driver.get("https://www.naver.com")
        time.sleep(1)
        
        with open(filepath, 'r') as f:
            cookies = json.load(f)
        
        for cookie in cookies:
            # 만료된 쿠키 제거
            if 'expiry' in cookie:
                cookie['expiry'] = int(cookie['expiry'])
            try:
                driver.add_cookie(cookie)
            except Exception:
                pass
        
        driver.refresh()
        time.sleep(2)
        
        if check_login_status(driver):
            logger.info("✅ 쿠키 로그인 성공!")
            return True
        else:
            logger.warning("쿠키 만료됨, 재로그인 필요")
            return False
            
    except Exception as e:
        logger.error(f"쿠키 로드 실패: {e}")
        return False
