"""
브라우저 설정 모듈
undetected-chromedriver를 사용하여 봇 감지 우회
"""

import os
import logging
import undetected_chromedriver as uc
from selenium.webdriver.chrome.options import Options

logger = logging.getLogger(__name__)


def create_driver(headless=False, chrome_path=None, profile_dir=None):
    """
    봇 감지를 우회하는 Chrome 드라이버를 생성합니다.
    
    Args:
        headless: 헤드리스 모드 (화면 없이 실행)
        chrome_path: Chrome 실행 파일 경로 (선택)
        profile_dir: Chrome 프로필 디렉토리 (선택, 로그인 유지용)
    
    Returns:
        WebDriver 인스턴스
    """
    options = uc.ChromeOptions()
    
    # 기본 옵션
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--lang=ko-KR")
    
    # 프로필 디렉토리 (로그인 상태 유지)
    if profile_dir:
        options.add_argument(f"--user-data-dir={profile_dir}")
        logger.info(f"Chrome 프로필: {profile_dir}")
    
    # 헤드리스 모드
    if headless:
        options.add_argument("--headless=new")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-gpu")
    
    # 드라이버 생성
    try:
        driver_kwargs = {
            "options": options,
            "version_main": None,  # 자동 감지
        }
        
        if chrome_path:
            driver_kwargs["browser_executable_path"] = chrome_path
        
        driver = uc.Chrome(**driver_kwargs)
        
        # 추가 봇 감지 우회
        driver.execute_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
        )
        
        logger.info("✅ Chrome 드라이버 생성 완료")
        return driver
        
    except Exception as e:
        logger.error(f"❌ 드라이버 생성 실패: {e}")
        raise


def close_driver(driver):
    """드라이버를 안전하게 종료합니다."""
    try:
        driver.quit()
        logger.info("드라이버 종료")
    except Exception:
        pass
