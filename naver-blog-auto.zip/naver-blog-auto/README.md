# 네이버 블로그 자동 포스팅 🚀

Selenium + 키스트로크 방식으로 네이버 블로그에 자동으로 글을 올리는 프로그램입니다.

## 특징
- **키스트로크 방식 로그인** — 사람처럼 한 글자씩 입력하여 봇 감지 우회
- **쿠키 기반 세션 유지** — 한번 로그인하면 쿠키 저장 → 재로그인 불필요
- **undetected-chromedriver** — Chrome 봇 감지 자동 우회
- **다양한 입력 방식** — 대화형, 파일, JSON, CLI 인자

## 설치

```bash
# 1. Python 3.10+ 필요
# 2. Chrome 브라우저 설치 필요

# 3. 의존성 설치
pip install -r requirements.txt

# 4. 환경 변수 설정
cp .env.example .env
# .env 파일 편집하여 네이버 ID/PW, 블로그 ID 입력
```

## 사용법

### 1) 첫 로그인 (쿠키 저장)
```bash
python main.py --login-only
```
→ 브라우저가 열리고 네이버에 로그인합니다.  
→ 캡차가 나오면 수동 입력 (최초 1회)  
→ 쿠키가 `cookies.json`에 저장됩니다.

### 2) 대화형 모드
```bash
python main.py
```
→ 제목, 본문, 태그, 카테고리를 하나씩 입력합니다.

### 3) CLI 모드
```bash
# 임시저장
python main.py --title "울산 타이어 교체 후기" --file content.txt --tags "울산타이어,타이어교체,미쉐린"

# 즉시 발행
python main.py --title "제목" --content "본문 내용" --publish
```

### 4) JSON 파일로 글 올리기
```bash
python main.py --json post.json
```

`post.json` 예시:
```json
{
  "title": "울산 미쉐린 타이어 교체 후기",
  "content": "오늘 타이어모어 울산학산점에서...",
  "tags": ["울산타이어", "미쉐린", "타이어교체"],
  "category": "타이어 작업",
  "publish": false
}
```

## 파일 구조
```
naver-blog-auto/
├── main.py            # 메인 실행 파일
├── naver_login.py     # 네이버 로그인 (키스트로크)
├── blog_poster.py     # 블로그 글 작성
├── browser_setup.py   # 브라우저 설정
├── requirements.txt   # Python 패키지
├── .env.example       # 환경 변수 예시
└── cookies.json       # 로그인 쿠키 (자동 생성)
```

## ⚠️ 주의사항
- **하루 1~2개** 이내로 포스팅하세요 (대량 포스팅 → 계정 제한 위험)
- 첫 로그인 시 **캡차**가 나올 수 있습니다 (수동 입력 필요)
- **2단계 인증** 설정된 경우 수동 처리 필요
- 네이버 UI 업데이트 시 셀렉터 수정이 필요할 수 있습니다
- `.env` 파일에 비밀번호가 저장되므로 **절대 공유하지 마세요**
