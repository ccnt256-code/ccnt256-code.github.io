@echo off
chcp 65001 >nul
echo ============================================
echo   네이버 블로그 자동 포스팅
echo ============================================
echo.
echo 1) 글쓰기 (대화형)
echo 2) 로그인만 (쿠키 저장)
echo 3) EXE 빌드 (실행파일 만들기)
echo 4) 종료
echo.
set /p choice="선택: "

if "%choice%"=="1" (
    python main.py
) else if "%choice%"=="2" (
    python main.py --login-only
) else if "%choice%"=="3" (
    echo.
    echo 📦 실행파일 빌드 중... (1~2분 소요)
    pip install pyinstaller >nul 2>&1
    pyinstaller --onefile --name "네이버블로그포스팅" --add-data ".env;." --hidden-import=undetected_chromedriver main.py
    echo.
    echo ✅ 빌드 완료! dist\네이버블로그포스팅.exe
    explorer dist
) else (
    exit /b 0
)

echo.
pause
