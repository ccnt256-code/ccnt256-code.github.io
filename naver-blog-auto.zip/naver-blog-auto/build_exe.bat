@echo off
chcp 65001 >nul
echo ============================================
echo   EXE 실행파일 빌드
echo ============================================
echo.

pip install pyinstaller >nul 2>&1

echo 📦 빌드 중... (1~2분 걸립니다)
echo.

pyinstaller ^
    --onefile ^
    --name "NaverBlogPoster" ^
    --add-data ".env.example;." ^
    --add-data "naver_login.py;." ^
    --add-data "blog_poster.py;." ^
    --add-data "browser_setup.py;." ^
    --hidden-import=undetected_chromedriver ^
    --hidden-import=dotenv ^
    --hidden-import=selenium ^
    main.py

echo.
if exist "dist\NaverBlogPoster.exe" (
    echo ✅ 빌드 성공!
    echo 📁 파일 위치: dist\NaverBlogPoster.exe
    echo.
    echo 사용법:
    echo   1. dist 폴더에 .env 파일 복사
    echo   2. NaverBlogPoster.exe 더블클릭
    explorer dist
) else (
    echo ❌ 빌드 실패. 에러 메시지를 확인해주세요.
)

echo.
pause
